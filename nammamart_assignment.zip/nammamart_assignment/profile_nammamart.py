import pandas as pd
import os

data_dir = os.path.join('include', 'data', 'nammamart')
files = ['orders.csv', 'payments.csv', 'customers.csv', 'products.csv', 'stores.csv']

print("=== NAMMAMART DATA PROFILING REPORT ===\n")

for file in files:
    filepath = os.path.join(data_dir, file)
    if not os.path.exists(filepath):
        print(f"ERROR: {file} not found at {filepath}")
        continue
        
    df = pd.read_csv(filepath)
    print(f"--- Profiling {file} ---")
    print(f"Total Rows: {len(df)}")
    print(f"Total Columns: {len(df.columns)}")
    
    nulls = df.isnull().sum()
    nulls = nulls[nulls > 0]
    if not nulls.empty:
        print("Missing Values (Nulls):")
        print(nulls.to_string())
    else:
        print("Missing Values: None")
        
    print(f"Duplicate Rows: {df.duplicated().sum()}")
    
    if file == 'orders.csv':
        print("Distinct Order Statuses:", df['order_status'].unique())
        print("Distinct Payment Modes:", df['payment_mode'].unique())
        print("Min/Max Quantity:", df['quantity'].min(), "to", df['quantity'].max())
        if 'delivery_minutes' in df.columns:
            print("Min/Max Delivery Minutes:", df['delivery_minutes'].min(), "to", df['delivery_minutes'].max())
        
    elif file == 'payments.csv':
        print("Distinct Payment Statuses:", df['payment_status'].unique())
        print("Distinct Payment Modes:", df['payment_mode'].unique())
        
    elif file == 'products.csv':
        bad_pricing = df[df['cost_price'] > df['mrp']]
        print(f"Products where Cost > MRP: {len(bad_pricing)}")
        
    print("\n")