from airflow.decorators import dag, task
import pendulum
import pandas as pd
import duckdb
import os

# Schedule: 9:00 AM IST, Monday to Saturday
IST = pendulum.timezone("Asia/Kolkata")

default_args = {
    'owner': 'niranjan',
    'retries': 1,
    'retry_delay': pendulum.duration(minutes=2),
    'execution_timeout': pendulum.duration(minutes=30)
}

@dag(
    dag_id='nammamart_etl_niranjan',
    default_args=default_args,
    start_date=pendulum.datetime(2026, 10, 1, tz=IST),
    schedule="0 9 * * 1-6", 
    catchup=False, 
    tags=['nammamart', 'etl']
)
def nammamart_etl():
    
    DATA_DIR = 'include/data/nammamart/'
    QUARANTINE_DIR = 'include/quarantine/niranjan/'
    DB_PATH = 'include/warehouse_niranjan.duckdb'
    
    @task
    def process_dimensions():
        customers = pd.read_csv(f'{DATA_DIR}customers.csv')
        products = pd.read_csv(f'{DATA_DIR}products.csv')
        stores = pd.read_csv(f'{DATA_DIR}stores.csv')
        
        # Deduplicate
        if 'customer_id' in customers.columns:
            customers = customers.drop_duplicates(subset=['customer_id'])
        if 'product_id' in products.columns:
            products = products.drop_duplicates(subset=['product_id'])
        if 'store_id' in stores.columns:
            stores = stores.drop_duplicates(subset=['store_id'])
        
        # Mask PII safely (checks if columns actually exist first to prevent crashes)
        if 'email' in customers.columns:
            customers['email'] = customers['email'].apply(
                lambda x: str(x)[:2] + '***@' + str(x).split('@')[1] if pd.notnull(x) and '@' in str(x) else x
            )
        if 'phone' in customers.columns:
            customers['phone'] = customers['phone'].apply(
                lambda x: str(x)[:2] + '******' + str(x)[-2:] if pd.notnull(x) and len(str(x)) >= 4 else x
            )
        
        # Load to DuckDB
        conn = duckdb.connect(DB_PATH)
        conn.execute("CREATE TABLE IF NOT EXISTS etl_dim_customer AS SELECT * FROM customers WHERE 1=0")
        conn.execute("CREATE TABLE IF NOT EXISTS etl_dim_product AS SELECT * FROM products WHERE 1=0")
        conn.execute("CREATE TABLE IF NOT EXISTS etl_dim_store AS SELECT * FROM stores WHERE 1=0")
        
        conn.execute("DELETE FROM etl_dim_customer; INSERT INTO etl_dim_customer SELECT * FROM customers")
        conn.execute("DELETE FROM etl_dim_product; INSERT INTO etl_dim_product SELECT * FROM products")
        conn.execute("DELETE FROM etl_dim_store; INSERT INTO etl_dim_store SELECT * FROM stores")
        conn.close()

    @task
    def process_facts_and_quarantine():
        orders = pd.read_csv(f'{DATA_DIR}orders.csv')
        payments = pd.read_csv(f'{DATA_DIR}payments.csv')
        
        orders['failure_reason'] = None
        
        # Rule 1: Validity - Invalid status
        valid_statuses = ['DELIVERED', 'CANCELLED', 'RETURNED']
        orders.loc[~orders['order_status'].isin(valid_statuses), 'failure_reason'] = 'Invalid Order Status'
        
        # Rule 2: Accuracy - Negative Quantity
        orders.loc[orders['quantity'] <= 0, 'failure_reason'] = 'Negative or Zero Quantity'
        
        # Rule 3: Accuracy - Impossible Delivery Time
        if 'delivery_minutes' in orders.columns:
            orders.loc[orders['delivery_minutes'] > 120, 'failure_reason'] = 'Delivery time > 120 mins'
            
        # Rule 4: Timeliness/Validity - Catch the fake "Month 13" dates using errors='coerce'
        orders['parsed_ts'] = pd.to_datetime(orders['order_ts'], errors='coerce')
        orders.loc[orders['parsed_ts'].isnull(), 'failure_reason'] = 'Invalid Timestamp format'
        
        # Split Good and Bad
        bad_orders = orders[orders['failure_reason'].notnull()].drop(columns=['parsed_ts'])
        good_orders = orders[orders['failure_reason'].isnull()].copy()
        
        # Save Quarantine
        os.makedirs(QUARANTINE_DIR, exist_ok=True)
        bad_orders.to_csv(f'{QUARANTINE_DIR}orders_failed_latest.csv', index=False)
        
        # Transform Good Data
        payment_mapping = {'upi': 'UPI', 'UPI ': 'UPI', 'cod': 'Cash on Delivery', 'Cashh': 'Cash on Delivery', 'CARD': 'Card'}
        good_orders['payment_mode'] = good_orders['payment_mode'].replace(payment_mapping)
        
        good_orders['order_ts'] = good_orders['parsed_ts']
        good_orders['order_date'] = good_orders['order_ts'].dt.date
        
        if 'delivery_minutes' in good_orders.columns:
            good_orders['within_15_min'] = good_orders['delivery_minutes'] <= 15
            
        good_orders = good_orders.drop(columns=['parsed_ts'])
        
        # Load
        conn = duckdb.connect(DB_PATH)
        conn.execute("CREATE TABLE IF NOT EXISTS etl_fact_orders AS SELECT * FROM good_orders WHERE 1=0")
        conn.execute("CREATE TABLE IF NOT EXISTS raw_payments AS SELECT * FROM payments WHERE 1=0")
        
        conn.execute("DELETE FROM etl_fact_orders; INSERT INTO etl_fact_orders SELECT * FROM good_orders")
        conn.execute("DELETE FROM raw_payments; INSERT INTO raw_payments SELECT * FROM payments")
        conn.close()

    @task
    def reconcile_and_report():
        conn = duckdb.connect(DB_PATH)
        
        reconciliation_query = """
            CREATE OR REPLACE TABLE etl_payment_reconciliation AS
            SELECT 
                o.order_id, 
                o.order_amount, 
                p.amount_paid,
                p.payment_status,
                CASE 
                    WHEN p.amount_paid IS NULL THEN 'Missing Payment'
                    WHEN o.order_amount != p.amount_paid THEN 'Amount Mismatch'
                    ELSE 'Reconciled'
                END AS mismatch_reason
            FROM etl_fact_orders o
            LEFT JOIN raw_payments p ON o.order_id = p.order_id
            WHERE o.order_status = 'DELIVERED' 
              AND (p.amount_paid IS NULL OR o.order_amount != p.amount_paid);
        """
        conn.execute(reconciliation_query)
        
        # Report
        conn.execute("""
            CREATE OR REPLACE TABLE etl_daily_zone_revenue AS
            SELECT s.zone, s.store_name, SUM(o.order_amount) as net_revenue
            FROM etl_fact_orders o
            JOIN etl_dim_store s ON o.store_id = s.store_id
            WHERE o.order_status = 'DELIVERED'
            GROUP BY 1, 2;
        """)
        conn.close()

    # Define sequential execution to prevent DuckDB locking
    dim_task = process_dimensions()
    fact_task = process_facts_and_quarantine()
    recon_task = reconcile_and_report()
    
    dim_task >> fact_task >> recon_task

etl_dag = nammamart_etl()