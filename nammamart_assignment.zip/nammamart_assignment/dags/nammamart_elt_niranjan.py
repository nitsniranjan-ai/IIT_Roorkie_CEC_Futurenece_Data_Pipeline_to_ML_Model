from airflow.decorators import dag, task
import pendulum
import duckdb
import os

# Schedule: 9:00 AM IST, Monday to Saturday
IST = pendulum.timezone("Asia/Kolkata")

default_args = {
    'owner': 'niranjan',
    'retries': 1,
    'retry_delay': pendulum.duration(minutes=2),
    'execution_timeout': pendulum.duration(minutes=30)
}

@dag(
    dag_id='nammamart_elt_niranjan',
    default_args=default_args,
    start_date=pendulum.datetime(2026, 10, 1, tz=IST),
    schedule="0 9 * * 1-6", 
    catchup=False, 
    tags=['nammamart', 'elt']
)
def nammamart_elt():
    
    DATA_DIR = 'include/data/nammamart/'
    QUARANTINE_DIR = 'include/quarantine/niranjan/'
    DB_PATH = 'include/warehouse_niranjan.duckdb'
    
    @task
    def extract_and_load_raw():
        """E & L phase: Load raw CSVs directly into DuckDB without changing anything."""
        conn = duckdb.connect(DB_PATH)
        # all_varchar=True prevents crashes from bad data types (like Month 13) during load
        conn.execute(f"CREATE OR REPLACE TABLE raw_customers AS SELECT * FROM read_csv_auto('{DATA_DIR}customers.csv', all_varchar=True)")
        conn.execute(f"CREATE OR REPLACE TABLE raw_products AS SELECT * FROM read_csv_auto('{DATA_DIR}products.csv', all_varchar=True)")
        conn.execute(f"CREATE OR REPLACE TABLE raw_stores AS SELECT * FROM read_csv_auto('{DATA_DIR}stores.csv', all_varchar=True)")
        conn.execute(f"CREATE OR REPLACE TABLE raw_orders AS SELECT * FROM read_csv_auto('{DATA_DIR}orders.csv', all_varchar=True)")
        conn.execute(f"CREATE OR REPLACE TABLE raw_payments AS SELECT * FROM read_csv_auto('{DATA_DIR}payments.csv', all_varchar=True)")
        conn.close()

    @task
    def transform_dimensions():
        """T phase: Clean and mask dimensions using pure SQL."""
        conn = duckdb.connect(DB_PATH)
        
        # Check if columns exist to prevent the missing schema trap
        cols = [r[1] for r in conn.execute("PRAGMA table_info('raw_customers')").fetchall()]
        email_sql = "CONCAT(SUBSTR(email, 1, 2), '***@', SPLIT_PART(email, '@', 2)) AS email" if 'email' in cols else ""
        phone_sql = "CONCAT(SUBSTR(phone, 1, 2), '******', RIGHT(phone, 2)) AS phone" if 'phone' in cols else ""
        
        other_cols = [c for c in cols if c not in ('email', 'phone')]
        select_cols = ', '.join(other_cols + ([email_sql] if email_sql else []) + ([phone_sql] if phone_sql else []))
        
        # QUALIFY ROW_NUMBER() removes duplicates in SQL
        conn.execute(f"""
            CREATE OR REPLACE TABLE elt_dim_customer AS 
            SELECT {select_cols} FROM raw_customers 
            QUALIFY ROW_NUMBER() OVER(PARTITION BY customer_id) = 1;
        """)
        
        conn.execute("""
            CREATE OR REPLACE TABLE elt_dim_product AS 
            SELECT * FROM raw_products QUALIFY ROW_NUMBER() OVER(PARTITION BY product_id) = 1;
        """)
        
        conn.execute("""
            CREATE OR REPLACE TABLE elt_dim_store AS 
            SELECT * FROM raw_stores QUALIFY ROW_NUMBER() OVER(PARTITION BY store_id) = 1;
        """)
        conn.close()

    @task
    def transform_facts_and_quarantine():
        """T phase: Enforce data quality and quarantine bad rows using SQL."""
        conn = duckdb.connect(DB_PATH)
        os.makedirs(QUARANTINE_DIR, exist_ok=True)
        
        # 1. Identify bad rows (TRY_CAST safely handles fake dates without crashing!)
        conn.execute("""
            CREATE OR REPLACE TABLE elt_quarantine_orders AS
            SELECT *,
                CASE 
                    WHEN TRY_CAST(order_ts AS TIMESTAMP) IS NULL THEN 'Invalid Timestamp format'
                    WHEN order_status NOT IN ('DELIVERED', 'CANCELLED', 'RETURNED') THEN 'Invalid Order Status'
                    WHEN CAST(quantity AS INT) <= 0 THEN 'Negative or Zero Quantity'
                    WHEN CAST(delivery_minutes AS FLOAT) > 120 THEN 'Delivery time > 120 mins'
                    ELSE NULL
                END AS failure_reason
            FROM raw_orders
            WHERE failure_reason IS NOT NULL;
        """)
        
        # Export quarantine table to CSV
        conn.execute(f"COPY elt_quarantine_orders TO '{QUARANTINE_DIR}elt_orders_failed_latest.csv' (HEADER, DELIMITER ',');")
        
        # 2. Transform the good rows
        conn.execute("""
            CREATE OR REPLACE TABLE elt_fact_orders AS
            SELECT 
                order_id, customer_id, store_id, product_id,
                TRY_CAST(order_ts AS TIMESTAMP) AS order_ts,
                CAST(TRY_CAST(order_ts AS TIMESTAMP) AS DATE) AS order_date,
                order_status,
                CAST(quantity AS INT) AS quantity,
                CAST(order_amount AS FLOAT) AS order_amount,
                CASE payment_mode
                    WHEN 'upi' THEN 'UPI' WHEN 'UPI ' THEN 'UPI'
                    WHEN 'cod' THEN 'Cash on Delivery' WHEN 'Cashh' THEN 'Cash on Delivery'
                    WHEN 'CARD' THEN 'Card'
                    ELSE payment_mode
                END AS payment_mode,
                CAST(delivery_minutes AS FLOAT) AS delivery_minutes,
                CAST(delivery_minutes AS FLOAT) <= 15 AS within_15_min
            FROM raw_orders
            WHERE order_id NOT IN (SELECT order_id FROM elt_quarantine_orders);
        """)
        conn.close()

    @task
    def report_reconciliation():
        """Build the final data products."""
        conn = duckdb.connect(DB_PATH)
        conn.execute("""
            CREATE OR REPLACE TABLE elt_payment_reconciliation AS
            SELECT 
                o.order_id, o.order_amount, CAST(p.amount_paid AS FLOAT) AS amount_paid, p.payment_status,
                CASE 
                    WHEN p.amount_paid IS NULL THEN 'Missing Payment'
                    WHEN o.order_amount != CAST(p.amount_paid AS FLOAT) THEN 'Amount Mismatch'
                    ELSE 'Reconciled'
                END AS mismatch_reason
            FROM elt_fact_orders o
            LEFT JOIN raw_payments p ON o.order_id = p.order_id
            WHERE o.order_status = 'DELIVERED' 
              AND (p.amount_paid IS NULL OR o.order_amount != CAST(p.amount_paid AS FLOAT));
        """)
        conn.close()

    # Sequential execution to prevent locking
    extract_task = extract_and_load_raw()
    dim_task = transform_dimensions()
    fact_task = transform_facts_and_quarantine()
    report_task = report_reconciliation()
    
    extract_task >> dim_task >> fact_task >> report_task

elt_dag = nammamart_elt()