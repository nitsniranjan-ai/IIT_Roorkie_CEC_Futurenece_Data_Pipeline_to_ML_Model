# NammaMart FDE Assignment Submission
**Name:** Niranjan Arulselvam

## Part 0: Data Profiling & Issues Log

### Data Issues Log
| File | Row key | Column | Problem | Quality dimension | Proposed rule | Severity |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| `orders.csv` | `order_id` | `customer_id` | 18 rows have missing customer IDs | Completeness | `customer_id` cannot be null | Critical |
| `orders.csv` | `order_id` | `quantity` | Minimum quantity is -3 | Accuracy | `quantity` must be > 0 | Critical |
| `orders.csv` | `order_id` | `order_status` | Contains invalid values like 'Pending??' and 'delivered' | Validity | Must be exactly DELIVERED, CANCELLED, or RETURNED | Critical |
| `orders.csv` | `order_id` | `payment_mode` | Inconsistent naming ('upi', 'Cashh', 'CARD', 'cod') | Validity / Consistency | Must map to standard list (UPI, Card, Cash on Delivery, Wallet) | Warning (can be fixed in transform) |
| `orders.csv` | `order_id` | `delivery_minutes` | Max time is 1440 mins (24 hrs) for a 10-min service | Accuracy | `delivery_minutes` must be < 120 | Critical |
| `orders.csv` | `order_id` | (Whole row) | 12 exact duplicate rows | Uniqueness | Rows must be unique | Critical |
| `payments.csv`| `payment_id`| (Whole row) | 4 exact duplicate rows | Uniqueness | Rows must be unique | Critical |
| `products.csv`| `product_id`| `cost_price`, `mrp` | 5 products where cost > MRP | Accuracy | `cost_price` <= `mrp` | Critical |
| `products.csv`| `product_id`| `category` | 3 rows missing category | Completeness | `category` cannot be null | Critical |
| `stores.csv` | `store_id` | `zone` | 1 row missing zone | Completeness | `zone` cannot be null | Critical |

### 3 Questions for the Client (CTO / Finance)
1. **Negative Quantities:** We found orders with a quantity of `-3`. Are these intended to represent customer returns, or are they simple data-entry errors that should be quarantined?
2. **Extreme Delivery Times:** Some orders show a `delivery_minutes` value of 1440 (24 hours). Should these be excluded from the "15-minute SLA" metric, or quarantined entirely as invalid data?
3. **Missing Customers:** There are 18 orders with no `customer_id`. If they have a valid payment, do we still count them toward daily net revenue, or do we quarantine them because we cannot map them to a loyalty tier?